
<!doctype html >
<html lang="sd" dir="rtl">
<head>
<style>
input[type=text] {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  box-sizing: border-box;
  font-size: 30px; 
}
</style>
    <meta charset="utf-8">

<script type='text/javascript'>
jQuery( document ).ready(function( $ ) {
	var Sindhi=['ا','ب','ٻ','پ','ڀ','ت','ٺ','ٽ','ث','ٿ','ف','ڦ','گ','ڳ','ڱ','ک','ي','د','ذ','ڌ','ڏ','ڊ','ڍ','ح','ج','ڄ','ڃ','چ','ڇ','خ','ع','غ','ر','ڙ','م','ن','ل','س','ش','و','ق','ص','ض','ڻ','ط','ظ','ھ','جھ','گھ','ڪ','ء','ه','آ'];	
	for(var index=0;index<Sindhi.length;index++)
    {
		$('p:contains('+Sindhi[index]+')').attr("id","sd");
		$('h1:contains('+Sindhi[index]+')').attr("id","sd");
		$('h2:contains('+Sindhi[index]+')').attr("id","sd");
		$('h3:contains('+Sindhi[index]+')').attr("id","sd");
		$('h4:contains('+Sindhi[index]+')').attr("id","sd");
		$('span:contains('+Sindhi[index]+')').attr("id","sd");
		$('a:contains('+Sindhi[index]+')').addClass( "sd" );
		$('li:contains('+Sindhi[index]+')').addClass( "sd" );
		$('legend:contains('+Sindhi[index]+')').attr("id","sd");
		$('label:contains('+Sindhi[index]+')').attr("id","sd");
		$('button:contains('+Sindhi[index]+')').attr("id","sd");
		$( "input[placeholder*='"+Sindhi[index]+"']" ).attr("id","sd");
		$( "input[value*='"+Sindhi[index]+"']" ).attr("id","sd");
		$('select:contains('+Sindhi[index]+')').attr("id","sd");
		$('tr:contains('+Sindhi[index]+')').addClass( "sd" );
		$('td:contains('+Sindhi[index]+')').attr("id","sd");
		$('div:contains('+Sindhi[index]+')').addClass( "sd" );
		$('strong:contains('+Sindhi[index]+')').attr("id","sd");			
	}
	function isUnicode(str)
	{
		var letters=[];
		for(var i=0;i<=str.length;i++)
		{
			letters[i]=str.substring((i-1),i);
			if(letters[i].charCodeAt()>255)
			{
				return true;
			}
		}
		return false;
	}
	var dir=$('textarea');
	dir.keyup(function(e)
	{
		if(isUnicode(dir.val()))
		{
			$('input').css('direction','rtl');
			$('input').attr("dir","auto");
			$('textarea').css('direction','rtl');
			$('textarea').attr("dir","auto");
		}
		else
		{
			
			$('input').css('direction','ltr');
			$('input').attr("dir","auto");
			$('textarea').css('direction','ltr');
			$('textarea').attr("dir","auto");
		}
	});
});
</script>
  <link rel="stylesheet" href="sindhi2.css">




</head>

<?php 


global $servername;
	global $username;
	global $password;
	global $dbname;
	
include("../config.php");//////////////////////
global $id;
global $word;
global $withvowels;
global $wrote;
global $approved;
global $engletter;
global $sinletter;

global $editok;
echo "سنڌيءَ کان ديوناگريءَ جا آوازن جا بنيادي ايڪا لکو، جيڪي آوازي نشانيون ٻنھي حرف علت ۽ حرف صحيح لاءِ استعمال ٿين انھن اڳيان true لکو";


       echo "<BR><BR><form method=\"POST\" name=\"addvowels\"  
	   id=\"addvowels\" action=\"\"> 
	  Devnagari alternate <input type=\"text\" name=\"engunits\" id=\"engunits\" value=\""; if(isset($_GET['engletter'])){echo $_GET['engletter'];} echo "\">
	  sindhi alternate
	 <font size=20><input type=\"text\" name=\"sinunits\" id=\"sinunits\" value=\""; if(isset($_GET['sinletter'])){echo $_GET['sinletter'];}echo "\">
	</font>
	
	is it sounds consonant and vowel both only 'true' or 'false'
	 <font size=20><input type=\"text\" name=\"consonants\" id=\"consonants\" value=\""; if(isset($_GET['consonants'])){echo $_GET['consonants'];}echo "\">
	</font>
<input type=\"submit\" name=\"submit\" onClick=\"location.href='#$id'\" value='newsubmit'>


 </form>
 
 <form method=POST action='units.php'><input type=\"submit\" name=\"refresh\" value='refresh'></form>

 
 ";
 ///////////
 $conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
mysqli_set_charset($conn,"utf8");
$sql = "SELECT * FROM duplicate_dev";
$result = $conn->query($sql);



if ($result->num_rows > 0) {
	

    // output data of each row
    while($row = $result->fetch_assoc()) {
		
	$id= $row["id"];
	$engletter=	$row["engletter"];
	$sinletter=	$row["sinletter"];
	$consonants=$row['consonants'];
	////
	if(isset($_POST['edit'.$id]))
	{
		$editok='true';
		if($editok=='true')
{
	if(isset($_POST['submit'])){
	///////////////////
	$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
mysqli_set_charset($conn,"utf8");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

//$sql = "select * from duplicate_dev where engletter='$engletter' and sinletter='$sinletter'";
$idd=$_GET['id'];
$sql = "update duplicate_dev set sinletter='$sinletter', engletter='$engletter', consonants='$consonants' where id=$idd";
echo "<BR>".$sql."<BR>";

if ($conn->query($sql) === TRUE) {
    echo "Record updated successfully";
	//header("Refresh:0");
} else {
    echo "Error updating record: " . $conn->error;
}
///////////////////////////
	
	
	}
	
	
	}
	else
	{
		$editok='false';
		}
	}
	/////
	
	if(isset($_POST['delete'.$id])){
			echo "love";
		$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
mysqli_set_charset($conn,"utf8");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$sql = "Delete from duplicate_dev where id=$id";
echo $sql;

if ($conn->query($sql) === TRUE) {
    echo "Record deleted successfully";
	//header("Refresh:0");
} else {
    echo "Error updating record: " . $conn->error;
}	
		}


	
	
	
	/////
	}
}
		
 
 
 
 
 
 
 
 
 ///////////////////////////
 if (isset($_POST["submit"])){

	 if(isset($_POST['engunits'])){$engletter=$_POST['engunits'];}
if(isset($_POST['sinunits'])){$sinletter=$_POST['sinunits'];}
if(isset($_POST['consonants'])){$consonants=$_POST['consonants'];}

if(isset($_GET['id']))
{
	///////////////////
	$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
mysqli_set_charset($conn,"utf8");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

//$sql = "select * from duplicate_dev where engletter='$engletter' and sinletter='$sinletter'";
$idd=$_GET['id'];
$sql = "update duplicate_dev set sinletter='$sinletter', engletter='$engletter', consonants='$consonants' where id=$idd";
echo "<BR>".$sql."<BR>";

if ($conn->query($sql) === TRUE) {
    echo "Record updated successfully";
	//header("Refresh:0");
} else {
    echo "Error updating record: " . $conn->error;
}


//////////
}
else{
////////////////////

$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
mysqli_set_charset($conn,"utf8");
$sql = "select * from duplicate_dev where sinletter='$sinletter' and engletter='$engletter' and consonants='$consonants'";
$result = $conn->query($sql);



if ($result->num_rows > 0) {
	echo $engletter.$sinletter.$consonants."<BR>رڪارڊ اڳ ۾ ئي موجود آهي";

   }else{
/////////////////////////
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
mysqli_set_charset($conn,"utf8");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

//$sql = "select * from duplicate_dev where engletter='$engletter' and sinletter='$sinletter'";

$sql = "insert into duplicate_dev (id, engletter, sinletter, consonants) values(null, '$engletter', '$sinletter', '$consonants')";
echo $sql;

if ($conn->query($sql) === TRUE) {
    echo "Record updated successfully";
	//header("Refresh:0");
} else {
    echo "Error updating record: " . $conn->error;
}
   }
$conn->close();

 }}
	
//




echo "<table><tr><td>id</td><td>devnagari phonics</td><td>sindhi Phonics</td><td>consonants</td></tr>";

$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
mysqli_set_charset($conn,"utf8");
$sql = "SELECT * FROM duplicate_dev";
$result = $conn->query($sql);



if ($result->num_rows > 0) {
	

    // output data of each row
    while($row = $result->fetch_assoc()) {
		
	$id= $row["id"];
	$engletter=	$row["engletter"];
	$sinletter=	$row["sinletter"];
	$consonants=$row['consonants'];
		
		echo "<TR><TD><p id=\"$id\">$id</p></td><td>$engletter</td><td>$sinletter</td>
		<td>$consonants</td><td><form method='POST' name='dlt' 
		action='units.php?id=$id&engletter=$engletter&sinletter=$sinletter
		&consonants=$consonants&editok=$editok'>
		<input type='submit' name='edit$id' value='Edit' id=$id>
		<input type='submit' name='delete$id' value='Delete' id=$id>
		</form></td></tr>";
		
		if(isset($_POST['delete'.$id])){
			echo "love";
		$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
mysqli_set_charset($conn,"utf8");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$sql = "Delete from duplicate_dev where id=$id";
echo $sql;

if ($conn->query($sql) === TRUE) {
    echo "Record deleted successfully";
	//header("Refresh:0");
} else {
    echo "Error updating record: " . $conn->error;
}	
		}

}}
echo "</table>";


?>
<form method='POST'	  action='units.php'>

<input type="submit" name='deldupli' id= 'deldupli' value='deldupli'>
</form><?PHP
if(isset($_POST['deldupli'])){
echo "deldupli"	;
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
mysqli_set_charset($conn,"utf8");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$sql = "DELETE t1 FROM duplicate_dev t1 
  INNER JOIN duplicate_dev t2 WHERE t1.id < t2.id 
    AND t1.engletter = t2.engletter 
    AND t1.sinletter = t2.sinletter";
echo $sql;

if ($conn->query($sql) === TRUE) {
    echo "Record deleted successfully";
	//header("Refresh:0");
} else {
    echo "Error updating record: " . $conn->error;
}	
	
	
}

?>



