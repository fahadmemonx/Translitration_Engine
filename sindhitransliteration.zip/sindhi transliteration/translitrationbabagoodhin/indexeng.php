
<!doctype html >
<html lang="sd" dir="rtl">
<head>
<style>
input[type=text] {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  box-sizing: border-box;
  font-size: 30px; 
}
</style>
    <meta charset="utf-8">

<script type='text/javascript'>
jQuery( document ).ready(function( $ ) {
	var Sindhi=['ا','ب','ٻ','پ','ڀ','ت','ٺ','ٽ','ث','ٿ','ف','ڦ','گ','ڳ','ڱ','ک','ي','د','ذ','ڌ','ڏ','ڊ','ڍ','ح','ج','ڄ','ڃ','چ','ڇ','خ','ع','غ','ر','ڙ','م','ن','ل','س','ش','و','ق','ص','ض','ڻ','ط','ظ','ھ','جھ','گھ','ڪ','ء','ه','آ'];	
	for(var index=0;index<Sindhi.length;index++)
    {
		$('p:contains('+Sindhi[index]+')').attr("id","sd");
		$('h1:contains('+Sindhi[index]+')').attr("id","sd");
		$('h2:contains('+Sindhi[index]+')').attr("id","sd");
		$('h3:contains('+Sindhi[index]+')').attr("id","sd");
		$('h4:contains('+Sindhi[index]+')').attr("id","sd");
		$('span:contains('+Sindhi[index]+')').attr("id","sd");
		$('a:contains('+Sindhi[index]+')').addClass( "sd" );
		$('li:contains('+Sindhi[index]+')').addClass( "sd" );
		$('legend:contains('+Sindhi[index]+')').attr("id","sd");
		$('label:contains('+Sindhi[index]+')').attr("id","sd");
		$('button:contains('+Sindhi[index]+')').attr("id","sd");
		$( "input[placeholder*='"+Sindhi[index]+"']" ).attr("id","sd");
		$( "input[value*='"+Sindhi[index]+"']" ).attr("id","sd");
		$('select:contains('+Sindhi[index]+')').attr("id","sd");
		$('tr:contains('+Sindhi[index]+')').addClass( "sd" );
		$('td:contains('+Sindhi[index]+')').attr("id","sd");
		$('div:contains('+Sindhi[index]+')').addClass( "sd" );
		$('strong:contains('+Sindhi[index]+')').attr("id","sd");			
	}
	function isUnicode(str)
	{
		var letters=[];
		for(var i=0;i<=str.length;i++)
		{
			letters[i]=str.substring((i-1),i);
			if(letters[i].charCodeAt()>255)
			{
				return true;
			}
		}
		return false;
	}
	var dir=$('textarea');
	dir.keyup(function(e)
	{
		if(isUnicode(dir.val()))
		{
			$('input').css('direction','rtl');
			$('input').attr("dir","auto");
			$('textarea').css('direction','rtl');
			$('textarea').attr("dir","auto");
		}
		else
		{
			
			$('input').css('direction','ltr');
			$('input').attr("dir","auto");
			$('textarea').css('direction','ltr');
			$('textarea').attr("dir","auto");
		}
	});
});
</script>
  <link rel="stylesheet" href="sindhi2.css">




</head>

<?php 


global $servername;
	global $username;
	global $password;
	global $dbname;
include("../config.php");
//////////////////////
global $id;
global $word;
global $withvowels;
global $wrote;
global $approved;

echo "<h2>هِن لَفِظَ کي اَعِرابَ/حَرڪَتون/حَرَف صَحِي يا سُرَ يا زيرِ زَبَرَ ۽ پيشُ ڏِيو</h2>";

$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
mysqli_set_charset($conn,"utf8");
$sql = "SELECT * FROM tsrs_table5 WHERE wrote='false' order by id limit 1";
$result = $conn->query($sql);



if ($result->num_rows > 0) {
	global $userpw;
	$userpw="true";

    // output data of each row
    while($row = $result->fetch_assoc()) {
		
	$id= $row["id"];
	$word=	$row["word"];
	$withvowels=	$row["withvowels"];
	$worte=	$row["wrote"];
		$approved=$row["approved"];
		


}}
echo "<font size =30>$word</font>";	
echo "<font size =30>$id</font>";	
       echo "<BR><BR><form method=\"POST\" name=\"addvowels\"  id=\"addvowels\" action=\"\"> 
	 <font size=20>  <input type=\"text\" name=\"voweladder\" id=\"voweladder\"  value=\"$withvowels\"></font>
<input type=\"submit\" name=\"submit\" onClick=\"location.href='#$id'\">
 </form>";
 
 if (isset($_POST["submit"])){

	 if(isset($_POST['voweladder'])){$voweladder=$_POST['voweladder'];}


$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
mysqli_set_charset($conn,"utf8");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "UPDATE tsrs_table5 SET withvowels='$voweladder', wrote='true' where id=$id";
echo $sql;

if ($conn->query($sql) === TRUE) {
    echo "Record updated successfully";
	header("Refresh:0");
} else {
    echo "Error updating record: " . $conn->error;
}

$conn->close();

 }
 /////////////////////////////////////
 



global $servername;
	global $username;
	global $password;
	global $dbname;
include("../config.php");
global $word;
global $withvowels; 
global $id;

  echo "<BR><BR><form method=\"POST\" name=\"addvowels3\"  id=\"addvowels3\" action=\"\"> 
	  ڪو خاص لفظ ڳوليو سُر ڏيڻ لاءِ<font size=20> <input type=\"text\" name=\"findword\" id=\"findword\" value-''></font>
	 
	 
<input type=\"submit\" name=\"submit3\">
 </form>";
 global $idq;
 if(isset($_POST['submit3'])){
 if(isset($_POST['findword'])){$findword=$_POST['findword'];}
 $conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
mysqli_set_charset($conn,"utf8");
$sql = "SELECT * FROM tsrs_table5 WHERE word='$findword' order by id limit 1";
echo $sql;
$result = $conn->query($sql);



if ($result->num_rows > 0) {
	

    // output data of each row
    while($row = $result->fetch_assoc()) {
		
	$idq= $row["id"];
	$word=	$row["word"];
	$withvowels=	$row["withvowels"];
	$worte=	$row["wrote"];
		$approved=$row["approved"];
 echo "<font size =30>$word</font>";
		
 }
}


 }
 	echo "<BR><BR><form method=\"POST\" name=\"addvowels4\"  id=\"addvowels4\" action=\"index.php?id=$idq\" > 
	 اوهان جي ڳوليل لفظ کي سُر ڏيو<font size=20><input type=\"text\" name=\"addsur\" id=\"addsur\" value=\"$withvowels\" ></font>
	 <input type=\"text\" name=\"id\" id=\"id\" value=\"$idq\" >
	 
	
<input type=\"submit\" name=\"submit4\">
 </form>";
  if(isset($_GET['id'])){
		  $idq=$_GET['id'];
  echo $_GET['id'];}
  

	if(isset($_POST['submit4'])){
	  if(isset($_POST['id'])){
		  $idq=$_POST['id'];
  echo $_POST['id'];}
	 
	  if(isset($_POST['addsur'])){
		  $addsur=$_POST['addsur'];
	  echo $_POST['addsur'];
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
mysqli_set_charset($conn,"utf8");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "UPDATE tsrs_table5 SET withvowels='$addsur', wrote='true' where id=$idq";
echo $sql;

if ($conn->query($sql) === TRUE) {
    echo "Record updated successfully";
	header("Refresh:0");
} else {
    echo "Error updating record: " . $conn->error;
}

$conn->close();

	  
	  
	  
	  }
	 
 }	
	
 
 
  
	

  echo "<BR><font size=20>نئون لفظ داخل ڪريو</font><BR><form method=\"POST\" name=\"addvowels\"  id=\"addvowels\" action=\"\"> 
	  سنڌي لفظ بغير سُرن جي<input type=\"text\" name=\"word\" id=\"word\" >
	  سنڌي لفظ سُرن سان
	 <font size=20><input type=\"text\" name=\"withvowels\" id=\"withvowels\" >
	</font>
<input type=\"submit\" name=\"submit2\">
 </form>";
 
 if (isset($_POST["submit2"])){

	 if(isset($_POST['word'])){$word=$_POST['word'];}
if(isset($_POST['withvowels'])){$withvowels=$_POST['withvowels'];}


////////////////////

$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
mysqli_set_charset($conn,"utf8");
$sql = "select * from tsrs_table5 where word='$word' ";
$result = $conn->query($sql);



if ($result->num_rows > 0) {
	echo $word."--".$withvowels."<BR>رڪارڊ اڳ ۾ ئي موجود آهي";

   }else{
/////////////////////////
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
mysqli_set_charset($conn,"utf8");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

//$sql = "select * from duplicate_eng where engletter='$engletter' and sinletter='$sinletter'";

$sql = "insert into tsrs_table5 (id, word, withvowels, wrote, approved) 
values(null, '$word', '$withvowels', 'true', 'false')";
echo $sql;

if ($conn->query($sql) === TRUE) {
    echo "Record updated successfully";
	header("Refresh:0");
} else {
    echo "Error updating record: " . $conn->error;
}

$conn->close();

 }}
	
//
echo "<form method=\"POST\">
<input type=\"submit\" name='submitx' value='Delete Duplicate'>

</form>";
if(isset($_POST['submitx'])){
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
mysqli_set_charset($conn,"utf8");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

//$sql = "select * from duplicate_eng where engletter='$engletter' and sinletter='$sinletter'";

$sql = "DELETE t1 FROM tsrs_table5 t1
INNER JOIN tsrs_table5 t2 
WHERE 
    t1.id < t2.id AND 
    t1.word = t2.word";
	 
if ($conn->query($sql) === TRUE) {
    echo "Record updated successfully";
	header("Refresh:0");
} else {
    echo "Error updating record: " . $conn->error;
}

$conn->close();

}

	
///////////////////////////////



?>
	  





