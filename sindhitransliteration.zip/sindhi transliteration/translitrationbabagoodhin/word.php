
<!doctype html >
<html lang="sd" dir="rtl">
<head>

  



</head>

<?php global $stringh;
global $f;
global $pre;
global $textt;
global $added;
global $final;



	$textt=$_POST['textt']." ";
	
	

//$textt="azahar chhanchhar fhd azahar ";
global $string;
global $stringh;
$stringh=array();
global $pp;

$textt = preg_replace("/[\\n\\r]+/", "", $textt);

$textt=str_replace("  ", " ", $textt);
$spcs=substr_count($textt, ' ');
//echo $spcs;

$stringh=(explode(" ",$textt));
include ("new.php");	
for($pp=0; $pp<=$spcs-1; $pp++){
//echo $stringh[$p]." ";
//$stringh[$pp]=str_replace(" ", "", $stringh[$pp]);
//echo $stringh[$p]."<BR>";
echo "<font face='tahoma'>";
$string=$stringh[$pp];

mb_internal_encoding('UTF-8');


include("workdone3.php");



global $wordpart;


$stln=mb_strlen($wordpart);

mb_internal_encoding('UTF-8');


$stln=mb_strlen($wordpart);

if (mb_substr($wordpart, $stln-2,2)=="اَ"){
	//echo mb_substr($wordpart, $stln-2,2);
	$wordpart=mb_substr_replace($wordpart, "ءَ",$stln-2,2);


}

if (mb_substr($wordpart, $stln-2,2)=="اِ"){
	//echo mb_substr($wordpart, $stln-2,2);
	$wordpart=mb_substr_replace($wordpart, "ءِ",$stln-2,2);


}

if (mb_substr($wordpart, $stln-2,2)=="اُ"){
	//echo mb_substr($wordpart, $stln-2,2);
	$wordpart=mb_substr_replace($wordpart, "ءُ",$stln-2,2);

}

/////////////////////////////////////////

for($i=0; $i<=mb_strlen($wordpart); $i++){

//echo strlen("world");
$vvl =mb_substr($wordpart, $i,1);
if ($vvl=="ا"){
	
$rplcabl =mb_substr($wordpart, $i+1,2);
if($rplcabl=="اِ"){
	
$wordpart= mb_substr_replace($wordpart,"ئِ" , $i+1,2);

}
}
}
for($i=0; $i<=mb_strlen($wordpart); $i++){
	$vvl =mb_substr($wordpart, $i,1);

if ($vvl=="ا"){
$rplcabl =mb_substr($wordpart, $i+1,2);
if($rplcabl=="اَ"){
	
$wordpart= mb_substr_replace($wordpart,"ئَ" , $i+1,2);
}
}
}
for($i=0; $i<=mb_strlen($wordpart); $i++){
	$vvl =mb_substr($wordpart, $i,1);
	if ($vvl=="ا"){
$rplcabl =mb_substr($wordpart, $i+1,2);
if($rplcabl=="اُ"){
$wordpart= mb_substr_replace($wordpart,"ئُ" , $i+1,2);


}
}
}


for($i=0; $i<=mb_strlen($wordpart); $i++){

//echo strlen("world");
$vvl =mb_substr($wordpart, $i,1);
if ($vvl=="آ"){
	
$rplcabl =mb_substr($wordpart, $i+1,2);
if($rplcabl=="اِ"){
	
$wordpart= mb_substr_replace($wordpart,"ئِ" , $i+1,2);

}
}
}
for($i=0; $i<=mb_strlen($wordpart); $i++){
	$vvl =mb_substr($wordpart, $i,1);

if ($vvl=="آ"){
$rplcabl =mb_substr($wordpart, $i+1,2);
if($rplcabl=="اَ"){
	
$wordpart= mb_substr_replace($wordpart,"ئَ" , $i+1,2);
}
}
}
for($i=0; $i<=mb_strlen($wordpart); $i++){
	$vvl =mb_substr($wordpart, $i,1);
	if ($vvl=="آ"){
$rplcabl =mb_substr($wordpart, $i+1,2);
if($rplcabl=="اُ"){
$wordpart= mb_substr_replace($wordpart,"ئُ" , $i+1,2);


}
}
}
for($i=0; $i<=mb_strlen($wordpart); $i++){
	$vvl =mb_substr($wordpart, $i,1);
if ($vvl=="و"){
$rplcabl =mb_substr($wordpart, $i+1,2);
if($rplcabl=="اِ"){
$wordpart= mb_substr_replace($wordpart,"ئِ" , $i+1,2);


}
}	
}
for($i=0; $i<=mb_strlen($wordpart); $i++){
	$vvl =mb_substr($wordpart, $i,1);
if ($vvl=="و"){
$rplcabl =mb_substr($wordpart, $i+1,2);
if($rplcabl=="اَ"){
$wordpart= mb_substr_replace($wordpart,"ئَ" , $i+1,2);



}
}	
}

for($i=0; $i<=mb_strlen($wordpart); $i++){
	$vvl =mb_substr($wordpart, $i,1);
if ($vvl=="و"){
$rplcabl =mb_substr($wordpart, $i+1,2);
if($rplcabl=="اُ"){
$wordpart= mb_substr_replace($wordpart,"ئُ" , $i+1,2);



}
}	
}


for($i=0; $i<=mb_strlen($wordpart); $i++){
	$vvl =mb_substr($wordpart, $i,1);
if ($vvl=="ي"){
$rplcabl =mb_substr($wordpart, $i+1,2);
if($rplcabl=="اِ"){
$wordpart= mb_substr_replace($wordpart,"ئِ" , $i+1,2);



}
}	
}


for($i=0; $i<=mb_strlen($wordpart); $i++){
	$vvl =mb_substr($wordpart, $i,1);
if ($vvl=="ي"){
$rplcabl =mb_substr($wordpart, $i+1,2);
if($rplcabl=="اَ"){
$wordpart= mb_substr_replace($wordpart,"ئَ" , $i+1,2);

}
}	
}

for($i=0; $i<=mb_strlen($wordpart); $i++){
	$vvl =mb_substr($wordpart, $i,1);
if ($vvl=="ي"){
$rplcabl =mb_substr($wordpart, $i+1,2);
if($rplcabl=="اُ"){
$wordpart= mb_substr_replace($wordpart,"ئُ" , $i+1,2);

}
}	
}

for($i=0; $i<=mb_strlen($wordpart); $i++){
	$vvl =mb_substr($wordpart, $i,1);
if ($vvl=="ِ"){
$rplcabl =mb_substr($wordpart, $i+1,2);
if($rplcabl=="اِ"){
$wordpart= mb_substr_replace($wordpart,"ئِ" , $i+1,2);

}
}	
}
for($i=0; $i<=mb_strlen($wordpart); $i++){
	$vvl =mb_substr($wordpart, $i,1);
if ($vvl=="ِ"){
$rplcabl =mb_substr($wordpart, $i+1,2);
if($rplcabl=="اَ"){
$wordpart= mb_substr_replace($wordpart,"ئَ" , $i+1,2);

}
}	
}
for($i=0; $i<=mb_strlen($wordpart); $i++){
	$vvl =mb_substr($wordpart, $i,1);
if ($vvl=="ِ"){
$rplcabl =mb_substr($wordpart, $i+1,2);
if($rplcabl=="اُ"){
$wordpart= mb_substr_replace($wordpart,"ئُ" , $i+1,2);

}
}	
}

for($i=0; $i<=mb_strlen($wordpart); $i++){
	$vvl =mb_substr($wordpart, $i,1);
if ($vvl=="َ"){
$rplcabl =mb_substr($wordpart, $i+1,2);
if($rplcabl=="اِ"){
$wordpart= mb_substr_replace($wordpart,"ئِ" , $i+1,2);

}
}	
}



for($i=0; $i<=mb_strlen($wordpart); $i++){
	$vvl =mb_substr($wordpart, $i,1);
if ($vvl=="َ"){
$rplcabl =mb_substr($wordpart, $i+1,2);
if($rplcabl=="اَ"){
$wordpart= mb_substr_replace($wordpart,"ئَ" , $i+1,2);

}
}	
}


for($i=0; $i<=mb_strlen($wordpart); $i++){
	$vvl =mb_substr($wordpart, $i,1);
if ($vvl=="َ"){
$rplcabl =mb_substr($wordpart, $i+1,2);
if($rplcabl=="اُ"){
$wordpart= mb_substr_replace($wordpart,"ئُ" , $i+1,2);

}
}	
}
for($i=0; $i<=mb_strlen($wordpart); $i++){
	$vvl =mb_substr($wordpart, $i,1);
if ($vvl=="ُ"){
$rplcabl =mb_substr($wordpart, $i+1,2);
if($rplcabl=="اِ"){
$wordpart= mb_substr_replace($wordpart,"ئِ" , $i+1,2);

}
}	
}

for($i=0; $i<=mb_strlen($wordpart); $i++){
	$vvl =mb_substr($wordpart, $i,1);
if ($vvl=="ُ"){
$rplcabl =mb_substr($wordpart, $i+1,2);
if($rplcabl=="اَ"){
$wordpart= mb_substr_replace($wordpart,"ئَ" , $i+1,2);

}
}	
}
for($i=0; $i<=mb_strlen($wordpart); $i++){
	$vvl =mb_substr($wordpart, $i,1);
if ($vvl=="ُ"){
$rplcabl =mb_substr($wordpart, $i+1,2);
if($rplcabl=="اُ"){
$wordpart= mb_substr_replace($wordpart,"ئُ" , $i+1,2);

}
}	
}
ok:
$i=0;







/////////////////////////////////////
//echo $stln;
//$midword=mb_substr($wordpart, 1, $stln-3);
//echo $midword;
//$strtng=mb_substr($wordpart, 0, 1);
//echo "<BR>".$strtng;
//$ending=mb_substr($wordpart,$stln-2, 2);
//echo "<BR>".$ending;
//$midword=str_replace($midword, 'اَ', 'ئَ');
//$midword=str_replace($midword, 'اِ', 'ئِ');

//$midword=str_replace($midword, 'اُ', 'ئُ');

//echo "<BR>".$strtng.$midword.$ending."<BR>";

//echo "<font color ='red'>".$wordpart."<font>";
$added=$added.$wordpart;



//$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
//if ($conn->connect_error) {
 // die("Connection failed: " . $conn->connect_error);
//} 
//mysqli_set_charset($conn,"utf8");

//$sql = "SELECT * FROM dic_duplicate  order by id limit 1";

//echo $sql."<BR><BR>--";	
//$result = $conn->query($sql);



//if ($result->num_rows > 0) {
	


	
	//while($row = $result->fetch_assoc()) {

	
	
	// echo $row['word'];
	 //$dic_duplicate=$row['word'];
	//}
	//}

//if($dic_duplicate==$wordpart){}else{

//$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
//if ($conn->connect_error) {
 // die("Connection failed: " . $conn->connect_error);
//}
//mysqli_set_charset($conn,"utf8");
//$sql = "UPDATE dic_duplicate SET word='$wordpart' WHERE id=1";

//if ($conn->query($sql) === TRUE) {
  //echo "Record updated successfully";
//} else {
 // echo "Error updating record: " . $conn->error;
//}

//$conn->close();
//}
//echo $string;

$wordpart="";
//$added="";
$added=$added." ";
$string="";
$added = preg_replace('~[\r\n]+~', '', $added);
$added = str_replace(array("<br>", "\r"), '', $added);
$added = str_replace(array("<BR>", "\r"), '', $added);

$added = trim(preg_replace('/\s+/', ' ', $added));
$final=$final.$added." ";
//echo $added;
//echo " ";
$added="";

}
//echo "</textarea>";
echo "<font size=20><textarea  rows='4' cols='50' name=\"texts\" class=\"form-control\" id=\"original\">"; echo $final; echo "</textarea></font>";
$final="";

$wordpart="";
$added="";
$string="";echo "</font></font>";?>
</html>