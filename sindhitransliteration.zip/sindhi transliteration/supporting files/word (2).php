
<!doctype html >
<html lang="sd" dir="rtl">
<head>
<style>
input[type=text] {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  box-sizing: border-box;
  font-size: 30px; 
}
</style>
    <meta charset="utf-8">

<script type='text/javascript'>
jQuery( document ).ready(function( $ ) {
	var Sindhi=['ا','ب','ٻ','پ','ڀ','ت','ٺ','ٽ','ث','ٿ','ف','ڦ','گ','ڳ','ڱ','ک','ي','د','ذ','ڌ','ڏ','ڊ','ڍ','ح','ج','ڄ','ڃ','چ','ڇ','خ','ع','غ','ر','ڙ','م','ن','ل','س','ش','و','ق','ص','ض','ڻ','ط','ظ','ھ','جھ','گھ','ڪ','ء','ه','آ'];	
	for(var index=0;index<Sindhi.length;index++)
    {
		$('p:contains('+Sindhi[index]+')').attr("id","sd");
		$('h1:contains('+Sindhi[index]+')').attr("id","sd");
		$('h2:contains('+Sindhi[index]+')').attr("id","sd");
		$('h3:contains('+Sindhi[index]+')').attr("id","sd");
		$('h4:contains('+Sindhi[index]+')').attr("id","sd");
		$('span:contains('+Sindhi[index]+')').attr("id","sd");
		$('a:contains('+Sindhi[index]+')').addClass( "sd" );
		$('li:contains('+Sindhi[index]+')').addClass( "sd" );
		$('legend:contains('+Sindhi[index]+')').attr("id","sd");
		$('label:contains('+Sindhi[index]+')').attr("id","sd");
		$('button:contains('+Sindhi[index]+')').attr("id","sd");
		$( "input[placeholder*='"+Sindhi[index]+"']" ).attr("id","sd");
		$( "input[value*='"+Sindhi[index]+"']" ).attr("id","sd");
		$('select:contains('+Sindhi[index]+')').attr("id","sd");
		$('tr:contains('+Sindhi[index]+')').addClass( "sd" );
		$('td:contains('+Sindhi[index]+')').attr("id","sd");
		$('div:contains('+Sindhi[index]+')').addClass( "sd" );
		$('strong:contains('+Sindhi[index]+')').attr("id","sd");			
	}
	function isUnicode(str)
	{
		var letters=[];
		for(var i=0;i<=str.length;i++)
		{
			letters[i]=str.substring((i-1),i);
			if(letters[i].charCodeAt()>255)
			{
				return true;
			}
		}
		return false;
	}
	var dir=$('textarea');
	dir.keyup(function(e)
	{
		if(isUnicode(dir.val()))
		{
			$('input').css('direction','rtl');
			$('input').attr("dir","auto");
			$('textarea').css('direction','rtl');
			$('textarea').attr("dir","auto");
		}
		else
		{
			
			$('input').css('direction','ltr');
			$('input').attr("dir","auto");
			$('textarea').css('direction','ltr');
			$('textarea').attr("dir","auto");
		}
	});
});
</script>
  <link rel="stylesheet" href="sindhi2.css">




</head>
<a href="word.php">roman to sindhi and sindhi to roman</a>
<a href="..\translitrationbabagoodurdu\word.php">اڙدو کان سنڌي ۽ سنڌيءَ کان اڙدو</a>
<a href="..\translitrationbabagoodipa\word.php">سنڌيءَ کان آءِ پي اي(عالمي صوتياتي ٻولي)</a>
<a href="..\translitrationbabagooddev\word.php">ديوناگري کان سنڌي ۽ ابتڙ</a>

<?php global $stringh;
global $f;
global $pre;
global $textt;

echo "<a href=\"units.php\"><h2>بنيادي ايڪا لکو</h2></a>";
echo "<a href=\"index.php\"><h2>لفظن کي سُر يا حرڪتون ڏيو</h2></a>";

echo "<font face='mb lateefi'>";
echo "<form method='POST'><BR>
<select name=\"script\">
  <option value=\"sindhi\">سنڌي کان رومن</option>
  <option value=\"roman\">roman khan Sindhi</option>
  
</select><BR>	


<textarea rows='4' cols='50' name=\"textt\" >"; if (isset($_POST['textt'])){$textt=$_POST['textt']; echo $textt;} echo "</textarea><BR><input type=\"submit\" name=\"submit\" onClick=\"location.href='#$id'\"></form>";
if(isset($_POST['submit'])){
	$textt=$_POST['textt']." ";
	if($_POST['script']=='sindhi'){
		echo "سنڌيءَ کان رومن<BR>";
		
	}
	if($_POST['script']=='roman'){
		echo "Roman to Sindhi<BR>";
		
	}
	
}
//$textt="azahar chhanchhar fhd azahar ";
global $string;
global $stringh;
$stringh=array();
global $pp;
$textt=str_replace("،", "", $textt);
$textt=str_replace("،", "", $textt);
$textt=str_replace("؛", "", $textt);
$textt=str_replace(":", "", $textt);
$textt=str_replace(")", "", $textt);
$textt=str_replace("(", "", $textt);

$textt=str_replace(".", "", $textt);
$textt=str_replace(",", "", $textt);
$textt=str_replace(";", "", $textt);
$textt=str_replace(":", "", $textt);
$textt=str_replace("(", "", $textt);
$textt=str_replace(")", "", $textt);
$textt = preg_replace("/[\\n\\r]+/", "", $textt);

$textt=str_replace("  ", " ", $textt);
$spcs=substr_count($textt, ' ');
//echo $spcs;

$stringh=(explode(" ",$textt));	
for($pp=0; $pp<=$spcs-1; $pp++){
//echo $stringh[$p]." ";
//$stringh[$pp]=str_replace(" ", "", $stringh[$pp]);
//echo $stringh[$p]."<BR>";
echo "<font face='mb lateefi'>";
$string=$stringh[$pp];

include("workdone3.php");
//echo $string;
echo " ";

$string="";
echo "</font></font>";
}
?>
</html>