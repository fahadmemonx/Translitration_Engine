
<!doctype html >
<html lang="sd" dir="rtl">
<head>
<style>
input[type=text] {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  box-sizing: border-box;
  font-size: 30px; 
}
</style>
    <meta charset="utf-8">

<script type='text/javascript'>
jQuery( document ).ready(function( $ ) {
	var Sindhi=['ا','ب','ٻ','پ','ڀ','ت','ٺ','ٽ','ث','ٿ','ف','ڦ','گ','ڳ','ڱ','ک','ي','د','ذ','ڌ','ڏ','ڊ','ڍ','ح','ج','ڄ','ڃ','چ','ڇ','خ','ع','غ','ر','ڙ','م','ن','ل','س','ش','و','ق','ص','ض','ڻ','ط','ظ','ھ','جھ','گھ','ڪ','ء','ه','آ'];	
	for(var index=0;index<Sindhi.length;index++)
    {
		$('p:contains('+Sindhi[index]+')').attr("id","sd");
		$('h1:contains('+Sindhi[index]+')').attr("id","sd");
		$('h2:contains('+Sindhi[index]+')').attr("id","sd");
		$('h3:contains('+Sindhi[index]+')').attr("id","sd");
		$('h4:contains('+Sindhi[index]+')').attr("id","sd");
		$('span:contains('+Sindhi[index]+')').attr("id","sd");
		$('a:contains('+Sindhi[index]+')').addClass( "sd" );
		$('li:contains('+Sindhi[index]+')').addClass( "sd" );
		$('legend:contains('+Sindhi[index]+')').attr("id","sd");
		$('label:contains('+Sindhi[index]+')').attr("id","sd");
		$('button:contains('+Sindhi[index]+')').attr("id","sd");
		$( "input[placeholder*='"+Sindhi[index]+"']" ).attr("id","sd");
		$( "input[value*='"+Sindhi[index]+"']" ).attr("id","sd");
		$('select:contains('+Sindhi[index]+')').attr("id","sd");
		$('tr:contains('+Sindhi[index]+')').addClass( "sd" );
		$('td:contains('+Sindhi[index]+')').attr("id","sd");
		$('div:contains('+Sindhi[index]+')').addClass( "sd" );
		$('strong:contains('+Sindhi[index]+')').attr("id","sd");			
	}
	function isUnicode(str)
	{
		var letters=[];
		for(var i=0;i<=str.length;i++)
		{
			letters[i]=str.substring((i-1),i);
			if(letters[i].charCodeAt()>255)
			{
				return true;
			}
		}
		return false;
	}
	var dir=$('textarea');
	dir.keyup(function(e)
	{
		if(isUnicode(dir.val()))
		{
			$('input').css('direction','rtl');
			$('input').attr("dir","auto");
			$('textarea').css('direction','rtl');
			$('textarea').attr("dir","auto");
		}
		else
		{
			
			$('input').css('direction','ltr');
			$('input').attr("dir","auto");
			$('textarea').css('direction','ltr');
			$('textarea').attr("dir","auto");
		}
	});
});
</script>
  <link rel="stylesheet" href="sindhi2.css">




</head>

<?php 


global $servername;
	global $username;
	global $password;
	global $dbname;
	
include("../config.php");//////////////////////
global $id;
global $word;
global $withvowels;
global $wrote;
global $approved;
global $engletter;
global $sinletter;

global $editok;
echo "سنڌيءَ ءٌ انگريزيءَ جا اھڙ
ا حرف جيڪي حرف صحيح يعني ڪانسوننٽس 
۽ حرف علت يعني واولس ٻنھي جو ڪم 
ڏين لکو جھڙوڪ سنڌي الف، و، ي، ع، ئ، . انگريزي
a, e, i , o, u, v, y, w 

اھي اکر جنھن بہ لفظ جي شروع ۾ ايندا ڪانسوننٽس جو ڪم ڏيندا، وچ ۾ ھوندا تہ بہ ڪانسوننٽس ھوندا
";


       echo "<BR><BR><form method=\"POST\" name=\"startingvowels\"  
	   id=\"addvowels\" action=\"\"> <font size=20>
	  starting consonant-vowels<input type=\"text\" name=\"sinengunits\" id=\"sinengunits\" value=\""; if(isset($_GET['conso_vowel'])){echo $_GET['conso_vowel'];} echo "\">
	 
	</font>
	
	
<input type=\"submit\" name=\"submit\" onClick=\"location.href='#$id'\" value='newsubmit'>


 </form>
 
 <form method=POST action='starting_vowels.php'><input type=\"submit\" name=\"refresh\" value='refresh'></form>

 
 ";
 ///////////
 $conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
mysqli_set_charset($conn,"utf8");
$sql = "SELECT * FROM  conso_vowel_engsin";
$result = $conn->query($sql);



if ($result->num_rows > 0) {
	

    // output data of each row
    while($row = $result->fetch_assoc()) {
		
	$id= $row["id"];
	$conso_vowel=	$row["conso_vowel"];
	$other=	$row["other"];
	
	////
	if(isset($_POST['edit'.$id]))
	{
		$editok='true';
		if($editok=='true')
{
	if(isset($_POST['submit'])){
	///////////////////
	$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
mysqli_set_charset($conn,"utf8");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

//$sql = "select * from duplicate_eng where engletter='$engletter' and sinletter='$sinletter'";
$idd=$_GET['id'];
$sql = "update  conso_vowel_engsin set conso_vowel='$sinengunits', other='', where id=$idd";
echo "<BR>".$sql."<BR>";

if ($conn->query($sql) === TRUE) {
    echo "Record updated successfully";
	//header("Refresh:0");
} else {
    echo "Error updating record: " . $conn->error;
}
///////////////////////////
	
	
	}
	
	
	}
	else
	{
		$editok='false';
		}
	}
	/////
	
	if(isset($_POST['delete'.$id])){
			echo "love";
		$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
mysqli_set_charset($conn,"utf8");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$sql = "Delete from  conso_vowel_engsin where id=$id";
echo $sql;

if ($conn->query($sql) === TRUE) {
    echo "Record deleted successfully";
	//header("Refresh:0");
} else {
    echo "Error updating record: " . $conn->error;
}	
		}


	
	
	
	/////
	}
}
		
 
 
 
 
 
 
 
 
 ///////////////////////////
 if (isset($_POST["submit"])){

	 if(isset($_POST['sinengunits'])){$sinengunits=$_POST['sinengunits'];}

if(isset($_GET['id']))
{
	///////////////////
	$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
mysqli_set_charset($conn,"utf8");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

//$sql = "select * from duplicate_eng where engletter='$engletter' and sinletter='$sinletter'";
$idd=$_GET['id'];
$sql = "update  conso_vowel_engsin set conso_vowel='$sinengunits', other='' where id=$idd";
echo "<BR>".$sql."<BR>";

if ($conn->query($sql) === TRUE) {
    echo "Record updated successfully";
	//header("Refresh:0");
} else {
    echo "Error updating record: " . $conn->error;
}


//////////
}
else{
////////////////////

$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
mysqli_set_charset($conn,"utf8");
$sql = "select * from  conso_vowel_engsin where conso_vowel='$sinengunits' ";
$result = $conn->query($sql);



if ($result->num_rows > 0) {
	echo $sinengunits.$other."<BR>رڪارڊ اڳ ۾ ئي موجود آهي";

   }else{
/////////////////////////
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
mysqli_set_charset($conn,"utf8");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

//$sql = "select * from duplicate_eng where engletter='$engletter' and sinletter='$sinletter'";

$sql = "insert into  conso_vowel_engsin (id, conso_vowel, other) values(null, '$sinengunits', '')";
echo $sql;

if ($conn->query($sql) === TRUE) {
    echo "Record updated successfully";
	//header("Refresh:0");
} else {
    echo "Error updating record: " . $conn->error;
}
   }
$conn->close();

 }}
	
//




echo "<table><tr><td>id</td><td>consonent vowels</td><td>Other</td></tr>";

$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
mysqli_set_charset($conn,"utf8");
$sql = "SELECT * FROM  conso_vowel_engsin";
$result = $conn->query($sql);



if ($result->num_rows > 0) {
	

    // output data of each row
    while($row = $result->fetch_assoc()) {
		
	$id= $row["id"];
	$conso_vowel=	$row["conso_vowel"];
	$other=	$row["other"];
	
		
		echo "<TR><TD><p id=\"$id\">$id</p></td><td>$conso_vowel</td><td>$other</td>
		<td><form method='POST' name='dlt' 
		action='starting_vowels.php?id=$id&conso_vowel=$conso_vowel&other=$other
		&editok=$editok'>
		<input type='submit' name='edit$id' value='Edit' id=$id>
		<input type='submit' name='delete$id' value='Delete' id=$id>
		</form></td></tr>";
		
		if(isset($_POST['delete'.$id])){
			echo "love";
		$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
mysqli_set_charset($conn,"utf8");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$sql = "Delete from  conso_vowel_engsin where id=$id";
echo $sql;

if ($conn->query($sql) === TRUE) {
    echo "Record deleted successfully";
	//header("Refresh:0");
} else {
    echo "Error updating record: " . $conn->error;
}	
		}

}}
echo "</table>";


?>
<form method='POST'	  action='starting_vowels.php'>

<input type="submit" name='deldupli' id= 'deldupli' value='deldupli'>
</form><?PHP
if(isset($_POST['deldupli'])){
echo "deldupli"	;
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
mysqli_set_charset($conn,"utf8");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$sql = "DELETE t1 FROM  conso_vowel_engsin t1 
  INNER JOIN  conso_vowel_engsin t2 WHERE t1.id < t2.id 
    AND t1.conso_vowel = t2.conso_vowel 
    AND t1.other = t2.other";
echo $sql;

if ($conn->query($sql) === TRUE) {
    echo "Record deleted successfully";
	//header("Refresh:0");
} else {
    echo "Error updating record: " . $conn->error;
}	
	
	
}

?>



