
<?php 

	///////////////////////////////
	ini_set('display_errors', 0);
ini_set('display_startup_errors', 0);
ini_set('max_execution_time', 600); 
//$string="fahad";
$strt=0;
$len=5;
global $dic_duplicate;
global $tillstring;
global $servername;
	global $username;
	global $password;
	global $dbname;
global $results;	
global $connx;
global $added;
include("config.php");
global $w;
$w=0;

global $q;
$q=array();
global $done;

	global $w;
$results='false';
	
	if ($_POST['script']=='sin_roman'){
	////////////
	$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
mysqli_set_charset($conn,"utf8");
$sql = "SELECT * FROM tsrs_table WHERE word='$string'  order by id limit 1";
$result = $conn->query($sql);



if ($result->num_rows > 0) {
	

    // output data of each row
    while($row = $result->fetch_assoc()) {
		
	$string= $row["withvowels"];
	$word=	$row["word"];
		
}

}else
{
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
mysqli_set_charset($conn,"utf8");
$sql = "SELECT * FROM tsrs_table WHERE withvowels='$string'  order by id limit 1";
$result = $conn->query($sql);



if ($result->num_rows > 0) {
	

    // output data of each row
    while($row = $result->fetch_assoc()) {
		
	$string= $row["withvowels"];
	$word=	$row["word"];
		
}

}	
}


}
	////////
	if ($_POST['script']=='roman_sin'){
	////////////
	$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
mysqli_set_charset($conn,"utf8");
$sql = "SELECT * FROM tsrs_table2 WHERE word='$string'  order by id limit 1";
$result = $conn->query($sql);



if ($result->num_rows > 0) {
	

    // output data of each row
    while($row = $result->fetch_assoc()) {
		
	$string= $row["withvowels"];
	$word=	$row["word"];
		
}

}else
{
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
mysqli_set_charset($conn,"utf8");
$sql = "SELECT * FROM tsrs_table2 WHERE withvowels='$string'  order by id limit 1";
$result = $conn->query($sql);



if ($result->num_rows > 0) {
	

    // output data of each row
    while($row = $result->fetch_assoc()) {
		
	$string= $row["withvowels"];
	$word=	$row["word"];
		
}

}	
}


}
	////////
	
global $n;	
$n=0;
$len=5;
global $ff;
$ff=0;
$done='true';




again:

if ($done=='true'){
	if ($n<=strlen($string)-1){


//if(($_POST['script'])=='sindhi'){
$tillstring = substr($string, $n, $len);
//echo "i=".$n."-- len=".$len."-- til --  ".$tillstring. "<BR>";
//}else
//{
//$tillstring = substr($string, $n, $len);
//echo "i=".$n."-- len=".$len."-- til --  ".$tillstring. "<BR>";
	
//}


//echo "i=".$n."-- len=".$len."-- til --  ".$tillstring. "<BR>";
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
mysqli_set_charset($conn,"utf8");
$sql = "SELECT * FROM vowels_eng_sin";
$result = $conn->query($sql);

$id= array();
		$sinvowel=array();
$engvowel=array();

if ($result->num_rows > 0) {
	

    // output data of each row
    while($row = $result->fetch_assoc()) {
		

	$id[]= $row["id"];
	$sinvowel[]= $row["sinvowel"];
	$engvowel[]=	$row["engvowel"];
	
	}
}

if (mb_strlen($tillstring)>= 3	){
for ($qh=1; $qh<=count($sinvowel)-1; $qh++){
	
	if(($sinvowel[$qh]==mb_substr($tillstring, 3, 1)) or ($engvowel[$qh]==mb_substr($tillstring,3, 1))){
	//echo "<BR>".mb_substr($tillstring, 1, 1).$sinvowel[$qh];"<BR>";
$len=2;
	for ($hq=1; $hq<=count($sinvowel)-1; $hq++){
		//echo $sinvowel[$hq]."<BR>";
	if(($sinvowel[$hq]==mb_substr($tillstring, 2, 1)) or ($engvowel[$hq]==mb_substr($tillstring, 2, 1))){
//echo "<BR>".mb_substr($tillstring, 3, 1).$sinvowel[$qh];"<BR>";
$len=3;
	$tillstring = mb_substr($string, $n, $len);
	//	echo "<BR>".$tillstring.": N:".$n.": len:".$len."<BR>";
	$qh=1;
	$hq=1;
	
	goto voweln;

	}	
		
		
	}
}
	
if(($sinvowel[$qh]==mb_substr($tillstring, 3, 1)) or ($engvowel[$qh]==mb_substr($tillstring, 3, 1))){
	//echo "<BR>".mb_substr($tillstring, 1, 1).$sinvowel[$qh];"<BR>";
$len=2;
	for ($hq=1; $hq<=count($sinvowel)-1; $hq++){
		//echo $sinvowel[$hq]."<BR>";
	if(($sinvowel[$hq]==mb_substr($tillstring, 2, 1)) or ($engvowel[$hq]==mb_substr($tillstring, 2, 1))){
//echo "<BR>".mb_substr($tillstring, 3, 1).$sinvowel[$qh];"<BR>";
$len=3;
	$tillstring = mb_substr($string, $n, $len);
	//	echo "<BR>".$tillstring.": N:".$n.": len:".$len."<BR>";
	$qh=1;
	$hq=1;
	
	goto vowelw;

	}	
		
		
	}
}
}
}
voweln:
vowelw:
/////////////////////
$strr=mb_substr($string, 0, 1);
$strr2=mb_substr($tillstring, 0, 1);
global $conn;



////////////////////
///////////
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
mysqli_set_charset($conn,"utf8");
$sql = "SELECT * FROM conso_vowel_engsin";
$result = $conn->query($sql);

$id= array();
		$conso_vowel=array();

if ($result->num_rows > 0) {
	

    // output data of each row
    while($row = $result->fetch_assoc()) {
		

	$id[]= $row["id"];
	$conso_vowel[]= $row["conso_vowel"];
	
	
	}
}



////////////////
for($g=0; $g<=count($conso_vowel); $g++){
	if($strr2==$conso_vowel[$g]){$cons_vov='true'; $g=0; goto convov; }else{$cons_vov='false';}
}
convov:
if($cons_vov=='true' ){


/////////////////////////


	


$conn = new mysqli($servername, $username, $password, $dbname);	
// Check connection
if ($conn->connect_error) {
   die("Connection failed: " . $connx->connect_error);
} 
mysqli_set_charset($conn,"utf8");
global $sql;
if ($_POST['script']=='roman_sin')
{

$sql = "SELECT * FROM duplicate_eng WHERE engletter='$tillstring' and consonants='true' order by id";
	}
	
	
if ($_POST['script']=='sin_roman')
{

$sql = "SELECT * FROM duplicate_eng WHERE sinletter='$tillstring' and consonants='true' order by id";
	}
	
	}
	
	
	
	
	
	else
	{
		if ($_POST['script']=='roman_sin'){

$sql = "SELECT * FROM duplicate_eng WHERE engletter='$tillstring' and consonants='false' order by id";
	}
	if ($_POST['script']=='sin_roman'){

$sql = "SELECT * FROM duplicate_eng WHERE sinletter='$tillstring' and consonants='false' order by id";
	}
	
	
	}
$result = $conn->query($sql);
global $m;
$m=0;

if ($result->num_rows > 0) {
//$results=$result->num_rows;
		
	
	
	while($row = $result->fetch_assoc()) {
		
		$ff=$ff+1;
		if($ff>=$result->num_rows)

{
$done='true';
$ff=0;
}else {$done='false';}

	if ($_POST['script']=='sin_roman'){

	$q[$w][$m]=$row['engletter']	;
	}
	if ($_POST['script']=='roman_sin'){

	$q[$w][$m]=$row['sinletter']	;
	}
	//echo $q[$w][$m]."<BR>";
	
	$m=$m+1;
	$n=$n+strlen($tillstring);
	$tillstring="";
	//echo $n."<BR>";
	$len=5;
//$len=5;
	
	//if ($len<=$n){
	
//	echo $tillstring;
	//$len=3;
	
//	$n=$n-1;
//}
	
	
	} //end of while
	
$w=$w+1;
	} //end of numrows
	else
	{

//if not found
$q[$w][$m]=$tillstring;
//echo $tillstring;
//if($_POST['script']=='sindhi'){
//$n=$n+strlen($tillstring);
//}
$tillstring="";
$len=$len-1;
if($len<1){
$len=5;
if($n<=strlen($string)-1){
goto q;
}
}

//goto again;
}

if($len<1){
$len=5;
if($n<=strlen($string)-1){
goto again;
}}

if($n<=strlen($string)-1){
goto again;
}


	}
}
	

 




	
	//print_r ($q)."<BR>	";
	
	
	
	q:
	
	
	global $q;

 

$arrPositions =array();
$arrResult = array();

//get a starting position set for each sub array
for ($i = 0; $i < count($q); $i++)
    $arrPositions[] = 0;

//repeat until we've run out of items in $q[0]
while (array_key_exists($arrPositions[0], $q[0])) {
    $arrTemp = array();
    $blSuccess = true;

    //go through each of the first array levels
    for ($i = 0; $i < count($q); $i++) {
        //is there a item in the position we want in the current array?
        if (array_key_exists($arrPositions[$i], $q[$i])) {
            //add that item to our temp array
            $arrTemp[] = $q[$i][$arrPositions[$i]];
        } else {
            //reset this position, and raise the one to the left
            $arrPositions[$i] = 0;
            $arrPositions[$i - 1]++;
            $blSuccess = false;
        }
    }

    //this one failed due to there not being an item where we wanted, skip to next go
    if (!$blSuccess) continue;

    //successfully adding nex line, increase the right hand count for the next one
    $arrPositions[count($q) - 1]++;

    //add our latest temp array to the result
    $arrResult[] = $arrTemp;
	
}


	
//print_r($arrResult);
	
	
	global $fahad;
	
	

	

for($i=0; $i<=count($arrResult)-1; $i++){
	
	
	
$count = count(reset($arrResult));
for ($x=0; $x<=$count-1; $x++){ //// 5 is max length of any of english alternates of sindhi.......eng letter Z has  alternatesض---س ص ث 
	
	



	
	$fahad=$fahad.$arrResult[$i][$x];
	
	//echo $arrResult[$i][$x];
	
}
 $fahad=$fahad."-";
}
//echo $fahad."<BR>";


$all  = $fahad;
$parts = explode("-", $all);
	global $results;
	$results='false';	
	
	 // $foo is here again
	$fahad="";
	
	
	$prt='false';
	$set=$string;
	$cnt=0;
for($i=0; $i<=count($parts)-1; $i++){



//echo $string."....this is string....";
//echo $parts[$i]."";
$parts[$i]=str_replace(" ", "", $parts[$i]);

/////////////////////////////////////




$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
   die("Connection failed: " . $conn->connect_error);
} 
mysqli_set_charset($conn,"utf8");
if ($_POST['script']=='roman_sin'){
$sql = "SELECT * FROM tsrs_table WHERE withvowels='$parts[$i]' order by id limit 1";
}
if ($_POST['script']=='sin_roman'){
$sql = "SELECT * FROM tsrs_table2 WHERE withvowels='$parts[$i]' order by id limit 1";
}
//echo $sql."<BR><BR>--";	
$result = $conn->query($sql);



if ($result->num_rows > 0) {
	
	
		

	
	while($row = $result->fetch_assoc()) {


		
		
		
	//if ($dic_duplicate==$row['withvowels']){}else{
				if(mb_strlen($row['withvowels'])>1){
if($string==$set){$cnt=$cnt+1;}
	if($cnt>1){$added=$added."/"; $cnt=1;}
	$added=$added.$row['withvowels']." ";

	//echo $row['withvowels']." ";
	
				$results='true';}else{$results='false';}
	//$updt_dicdupli=$row['withvowels'];

	
	
	
	
	
	
	
	}
	
	}else{//$results='false';
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
   die("Connection failed: " . $conn->connect_error);
} 
mysqli_set_charset($conn,"utf8");
if ($_POST['script']=='roman_sin'){
$sql = "SELECT * FROM tsrs_table WHERE word='$parts[$i]' order by id limit 1";
}
if ($_POST['script']=='sin_roman'){
$sql = "SELECT * FROM tsrs_table2 WHERE word='$parts[$i]' order by id limit 1";
}
//echo $sql."<BR><BR>--";	
$result = $conn->query($sql);



if ($result->num_rows > 0) {
	
	
	

	
	while($row = $result->fetch_assoc()) {

	
		//////////////////////////
		
		
		
		/////////////////////////
	///if($dic_duplicate==$row['word']){}else{
		
		if(mb_strlen($row['word'])>1){
			if($string==$set){$cnt=$cnt+1;}
	if($cnt>1){$added=$added."/"; $cnt=1;}
		$added=$added.$row['withvowels']." ";
		//echo $row['withvowels']." ";
		$results='true';
		if ($result->num_rows > 1) {
		$added=$added."/";
		}
		}
	//  $word=$row['word'];
	 
	 
	 
	 
	
	
	}
	
	}//else{$results='false';}
	}
//////////////////////////

}

//////////////////////////
//}	
?>

<?php

if ($results=='false'){
	
$results='false';
//echo $string."-";
$strt=0;
$len=5;
global $tillstring;
$tillstring="";
global $n;
$n=0;
global $servername;
	global $username;
	global $password;
	global $dbname;
global $results;	
include("config.php");
global $h;
$h=0;

global $q;
$q=array();
global $wordparts;

	global $h;
	

for ($n=$strt; $n<=mb_strlen($string)-1; $n++){
if (  $n<=mb_strlen($string)-1){



els: ech: 

$tillstring = mb_substr($string, $n, $len);
//echo "i=".$n."-- len=".$len."-- til --  ".$tillstring. "<BR>";
//echo $tillstring;
//echo substr($tillstring,$n+1,1)."<BR>";

//echo "i=".$n."-- len=".$len."-- til --  ".$tillstring. "<BR>";

//echo $tillstring."<-- tillstring";
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
mysqli_set_charset($conn,"utf8");
$sql = "SELECT * FROM vowels_eng_sin";
$result = $conn->query($sql);

$id= array();
		$sinvowel=array();
$engvowel=array();

if ($result->num_rows > 0) {
	

    // output data of each row
    while($row = $result->fetch_assoc()) {
		

	$id[]= $row["id"];
	$sinvowel[]= $row["sinvowel"];
	$engvowel[]=	$row["engvowel"];
	
	}
}

if (mb_strlen($tillstring)>=3	){
for ($qh=1; $qh<=count($sinvowel)-1; $qh++){
	if(($sinvowel[$qh]==mb_substr($tillstring, 2, 1)) or ($engvowel[$qh]==mb_substr($tillstring, 2, 1))){
	//echo "<BR>".mb_substr($tillstring, 1, 1).$sinvowel[$qh];"<BR>";
$len=3;
	for ($hq=1; $hq<=count($sinvowel)-1; $hq++){
		//echo $sinvowel[$hq]."<BR>";
	if(($sinvowel[$hq]==mb_substr($tillstring, 3, 1)) or ($engvowel[$hq]==mb_substr($tillstring, 3, 1))){
//echo "<BR>".mb_substr($tillstring, 3, 1).$sinvowel[$qh];"<BR>";
$len=2;
	$tillstring = mb_substr($string, $n, $len);
	//	echo "<BR>".$tillstring.": N:".$n.": len:".$len."<BR>";
	$qh=1;
	$hq=1;
	
	goto vowels;

	}	
		
		
	}
}
	
	
if(($sinvowel[$qh]==mb_substr($tillstring, 2, 1)) or ($engvowel[$qh]==mb_substr($tillstring, 2, 1))){
	//echo "<BR>".mb_substr($tillstring, 1, 1).$sinvowel[$qh];"<BR>";
$len=3;
	for ($hq=1; $hq<=count($sinvowel)-1; $hq++){
		//echo $sinvowel[$hq]."<BR>";
	if(($sinvowel[$hq]==mb_substr($tillstring, 3, 1)) or ($engvowel[$hq]==mb_substr($tillstring, 3, 1))){
//echo "<BR>".mb_substr($tillstring, 3, 1).$sinvowel[$qh];"<BR>";
$len=2;
	$tillstring = mb_substr($string, $n, $len);
	//	echo "<BR>".$tillstring.": N:".$n.": len:".$len."<BR>";
	$qh=1;
	$hq=1;
	
	goto vowel;

	}	
		
		
	}
}

	

}
}
vowel:
vowels:
/////////////////////


$strr=mb_substr($string, 0, 1);
$strr2=mb_substr($tillstring, 0, 1);
global $conn;
////////////
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
mysqli_set_charset($conn,"utf8");
$sql = "SELECT * FROM conso_vowel_engsin";
$result = $conn->query($sql);

$id= array();
		$conso_vowel=array();

if ($result->num_rows > 0) {
	

    // output data of each row
    while($row = $result->fetch_assoc()) {
		

	$id[]= $row["id"];
	$conso_vowel[]= $row["conso_vowel"];
	
	
	}
}



////////////////
//ech:
for($g=0; $g<=count($conso_vowel); $g++){
	if($strr2==$conso_vowel[$g]){$cons_vov='true'; $g=0; goto convov2; }else{$cons_vov='false';}
}
convov2:
if($cons_vov=='true' ){
	


	

	
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
   die("Connection failed: " . $conn->connect_error);
} 
mysqli_set_charset($conn,"utf8");
if ($_POST['script']=='sin_roman'){
$sql = "SELECT * FROM duplicate_eng WHERE sinletter='$tillstring' and consonants='true' order by id limit 1";
}

if ($_POST['script']=='roman_sin'){
$sql = "SELECT * FROM duplicate_eng WHERE engletter='$tillstring' and consonants='true' order by id limit 1";
}
}else{
	
	mysqli_set_charset($conn,"utf8");
if ($_POST['script']=='sin_roman'){
$sql = "SELECT * FROM duplicate_eng WHERE sinletter='$tillstring' and consonants='false' order by id limit 1";
}

if ($_POST['script']=='roman_sin'){
$sql = "SELECT * FROM duplicate_eng WHERE engletter='$tillstring' and consonants='false' order by id limit 1";
}
	
}

//echo $sql;	
$result = $conn->query($sql);
global $p;
$p=0;

if ($result->num_rows > 0) {
//$results=$result->num_rows;
		
	
	
	while($row = $result->fetch_assoc()) {
		if ($_POST['script']=='roman_sin'){

	$q[$h][$p]=$row['sinletter']	;
		}
			if ($_POST['script']=='sin_roman'){
				$q[$h][$p]=$row['engletter'];
				
			}

	//echo "<font color ='blue'>".$q[$h][$p]."</font>";
	$wordpart=$wordpart.$q[$h][$p];

	$p=$p+1;
	
	 $n=$n+$len;
	
//$len=3;
	if ($len=1){
		
		$len=5;
		$n=$n-1;
//echo $tillstring;
	}
	
	//if ($len<=$n){
	
//	echo $tillstring;
	//$len=3;
	
//	$n=$n-1;
//}
	
	
	} 
$h=$h+1;
	
	}
	else
	{

if($len<=1){
$len=5;

$q[$h][$p]=$tillstring;
//echo "<font color ='blue'>".$q[$h]	[$p]."</font>";
$wordpart=$wordpart.$q[$h]	[$p];
$p=$p+1;
$h=$h+1;
if($script=='sindhi'){
$n=$n+strlen($tillstring);}else{$n=$n+mb_strlen($tillstring);}
goto ech;
	}else{
		if($len<=0){$len=1; $n=$n-1; goto els;}else{
$len=$len-1;
		$n=$n-1;}

//	
	}
	//echo $wordpart;
	//$wordpart="";
	}
}
	

 


$results=0; 
	}
	//print_r ($q)."<BR>	";
	//echo $wordpart;
	//$wordpart="";
	
	
	
	
	
	
	
	
	

	
	}
		$paticle="";
	
////////////////////////
?>

