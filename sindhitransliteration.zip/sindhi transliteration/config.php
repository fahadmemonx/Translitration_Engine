<?PHP


$servername = "localhost";
$username = "root";
$password = "";
$dbname = "tsrs";
?>